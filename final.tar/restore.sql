--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3
-- Dumped by pg_dump version 16.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE armun;
--
-- Name: armun; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE armun WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE armun OWNER TO postgres;

\connect armun

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


--
-- Name: Level; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Level" AS ENUM (
    'ESCOLAR',
    'UNIVERSITARIO',
    'MIXED'
);


ALTER TYPE public."Level" OWNER TO postgres;

--
-- Name: MotionStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."MotionStatus" AS ENUM (
    'ONGOING',
    'FINISHED',
    'SUSPENDED'
);


ALTER TYPE public."MotionStatus" OWNER TO postgres;

--
-- Name: MotionType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."MotionType" AS ENUM (
    'MODERATED_CAUCUS',
    'UNMODERATED_CAUCUS',
    'CONSULTATION_OF_THE_WHOLE',
    'ROUND_ROBIN',
    'SPEAKERS_LIST',
    'SUSPENSION_OF_THE_MEETING',
    'ADJOURNMENT_OF_THE_MEETING',
    'CLOSURE_OF_DEBATE'
);


ALTER TYPE public."MotionType" OWNER TO postgres;

--
-- Name: Role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Role" AS ENUM (
    'DIRECTOR',
    'DIRECTORA',
    'DIRECTOR_ADJUNTO',
    'DIRECTORA_ADJUNTA',
    'MODERADOR',
    'MODERADORA',
    'CRISIS_ROOM'
);


ALTER TYPE public."Role" OWNER TO postgres;

--
-- Name: SessionStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."SessionStatus" AS ENUM (
    'ONGOING',
    'FINISHED',
    'SUSPENDED',
    'SCHEDULED'
);


ALTER TYPE public."SessionStatus" OWNER TO postgres;

--
-- Name: State; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."State" AS ENUM (
    'PRESENTE',
    'AUSENTE',
    'PRESENTE_Y_VOTANDO'
);


ALTER TYPE public."State" OWNER TO postgres;

--
-- Name: get_committee_attendance(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_committee_attendance(p_committee_id integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    committee_rec RECORD;
    session_rec RECORD;
    attendance_rec RECORD;
    committee_cursor CURSOR FOR
        SELECT id, name, topic, level
        FROM "Committee"
        WHERE id = p_committee_id;
    session_cursor CURSOR FOR
        SELECT id, date, status
        FROM "Session"
        ORDER BY date;
    attendance_cursor CURSOR (p_session_id INT) FOR
        SELECT a.state, d.name AS delegate_name, c.name AS country_name
        FROM "Asistencia" a
        JOIN "Delegate" d ON a."delegateId" = d.id
        JOIN "Country" c ON d."countryId" = c.id
        WHERE d."committeeId" = p_committee_id AND a."sessionId" = p_session_id
        ORDER BY c.name, d.name;
BEGIN
    OPEN committee_cursor;
    FETCH committee_cursor INTO committee_rec;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Committee with ID % not found', p_committee_id;
    END IF;

    RAISE NOTICE 'Committee: % (%) - Level: %', committee_rec.name, committee_rec.topic, committee_rec.level;

    OPEN session_cursor;
    LOOP
        FETCH session_cursor INTO session_rec;
        EXIT WHEN NOT FOUND;

        RAISE NOTICE '  Session Date: %, Status: %',
                     session_rec.date::date,
                     session_rec.status;

        RAISE NOTICE '    Attendance:';
        OPEN attendance_cursor(session_rec.id);
        LOOP
            FETCH attendance_cursor INTO attendance_rec;
            EXIT WHEN NOT FOUND;

            RAISE NOTICE '      - % (%) - Status: %',
                         attendance_rec.delegate_name,
                         attendance_rec.country_name,
                         attendance_rec.state;
        END LOOP;
        CLOSE attendance_cursor;

        RAISE NOTICE '';
    END LOOP;
    CLOSE session_cursor;

    CLOSE committee_cursor;
END;
$$;


ALTER FUNCTION public.get_committee_attendance(p_committee_id integer) OWNER TO postgres;

--
-- Name: get_committee_attendance_summary(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_committee_attendance_summary(p_committee_id integer) RETURNS TABLE(session_date date, session_status text, total_delegates integer, present_count integer, absent_count integer, present_and_voting_count integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    WITH committee_delegates AS (
        SELECT COUNT(*) AS total_delegates
        FROM "Delegate"
        WHERE "committeeId" = p_committee_id
    )
    SELECT
        s.date::DATE AS session_date,
        s.status::TEXT AS session_status,
        cd.total_delegates,
        COUNT(CASE WHEN a.state = 'PRESENTE' THEN 1 END) AS present_count,
        COUNT(CASE WHEN a.state = 'AUSENTE' THEN 1 END) AS absent_count,
        COUNT(CASE WHEN a.state = 'PRESENTE_Y_VOTANDO' THEN 1 END) AS present_and_voting_count
    FROM
        "Session" s
    LEFT JOIN "Asistencia" a ON s.id = a."sessionId"
    LEFT JOIN "Delegate" d ON a."delegateId" = d.id
    CROSS JOIN committee_delegates cd
    WHERE
        d."committeeId" = p_committee_id OR d."committeeId" IS NULL
    GROUP BY
        s.id, s.date, s.status, cd.total_delegates
    ORDER BY
        s.date;
END;
$$;


ALTER FUNCTION public.get_committee_attendance_summary(p_committee_id integer) OWNER TO postgres;

--
-- Name: get_committee_attendance_with_cursors(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_committee_attendance_with_cursors(committee_id integer) RETURNS TABLE(session_id integer, session_date date, presente_count integer, ausente_count integer, presente_y_votando_count integer)
    LANGUAGE plpgsql
    AS $$
DECLARE
    session_rec RECORD;
    attendance_rec RECORD;

    session_cursor CURSOR FOR
        SELECT DISTINCT s.id, s.date
        FROM "Session" s
        JOIN "Asistencia" a ON s.id = a."sessionId"
        JOIN "Delegate" d ON a."delegateId" = d.id
        WHERE d."committeeId" = committee_id;

    attendance_cursor CURSOR (v_session_id INT) FOR
        SELECT a.state, COUNT(*) AS state_count
        FROM "Asistencia" a
        JOIN "Delegate" d ON a."delegateId" = d.id
        WHERE a."sessionId" = v_session_id
        AND d."committeeId" = committee_id
        GROUP BY a.state;

BEGIN
    presente_count := 0;
    ausente_count := 0;
    presente_y_votando_count := 0;

    OPEN session_cursor;
    LOOP
        FETCH session_cursor INTO session_rec;
        EXIT WHEN NOT FOUND;

        -- Reset counts for each session
        presente_count := 0;
        ausente_count := 0;
        presente_y_votando_count := 0;

        OPEN attendance_cursor(session_rec.id);
        LOOP
            FETCH attendance_cursor INTO attendance_rec;
            EXIT WHEN NOT FOUND;

            CASE attendance_rec.state
                WHEN 'PRESENTE' THEN presente_count := attendance_rec.state_count;
                WHEN 'AUSENTE' THEN ausente_count := attendance_rec.state_count;
                WHEN 'PRESENTE_Y_VOTANDO' THEN presente_y_votando_count := attendance_rec.state_count;
            END CASE;
        END LOOP;
        CLOSE attendance_cursor;

        session_id := session_rec.id;
        session_date := session_rec.date;

        RETURN NEXT;
    END LOOP;
    CLOSE session_cursor;
END;
$$;


ALTER FUNCTION public.get_committee_attendance_with_cursors(committee_id integer) OWNER TO postgres;

--
-- Name: get_delegate_attendance_summary(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_delegate_attendance_summary(p_session_id integer) RETURNS TABLE(delegate_name text, delegate_id text, attendance_state public."State")
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT
        D.name AS delegate_name,
        A."delegateId" AS delegate_id,
        A.state AS attendance_state
    FROM
        "Asistencia" A
    JOIN
        "Delegate" D ON A."delegateId" = D.id
    WHERE
        A."sessionId" = p_session_id;
END;
$$;


ALTER FUNCTION public.get_delegate_attendance_summary(p_session_id integer) OWNER TO postgres;

--
-- Name: has_ongoing_session(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.has_ongoing_session(p_committee_id integer) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
  SELECT EXISTS(
    SELECT 1
    FROM "Session" s
    JOIN "Committee" c ON s.id = c.id
    WHERE c.id = p_committee_id AND s.status = 'ONGOING'
  );
$$;


ALTER FUNCTION public.has_ongoing_session(p_committee_id integer) OWNER TO postgres;

--
-- Name: prevent_delegate_participation_in_overlapping_sessions(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.prevent_delegate_participation_in_overlapping_sessions() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    overlapping_session RECORD;
BEGIN
    SELECT * INTO overlapping_session
    FROM "Asistencia" a
    JOIN "Session" s ON a."sessionId" = s.id
    WHERE a."delegateId" = NEW.delegateId AND
          (s."startTime", s."endTime") OVERLAPS (NEW.session->>s."startTime", NEW.session->>"s"."endTime")
    LIMIT 1;

    IF FOUND THEN
        RAISE EXCEPTION 'Delegate cannot participate in overlapping sessions';
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.prevent_delegate_participation_in_overlapping_sessions() OWNER TO postgres;

--
-- Name: set_default_start_time_for_session(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.set_default_start_time_for_session() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW."startTime" IS NULL THEN
        NEW."startTime" = NOW();
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.set_default_start_time_for_session() OWNER TO postgres;

--
-- Name: sp_close_motion(character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sp_close_motion(IN p_motion_id character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE "Motion"
    SET
       "createdAt" = NOW()
    WHERE id = p_motion_id;

    UPDATE "PassedMotion"
    SET status = 'FINISHED'
    WHERE "motionId" = p_motion_id;
END;
$$;


ALTER PROCEDURE public.sp_close_motion(IN p_motion_id character varying) OWNER TO postgres;

--
-- Name: sp_record_delegate_participation(character varying, character varying, integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sp_record_delegate_participation(IN p_passed_motion_id character varying, IN p_delegate_id character varying, IN p_time_used integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO "PassedMotionDelegate" ("id", "passedMotionId", "delegateId", "timeUsed")
    VALUES (gen_random_uuid(), p_passed_motion_id, p_delegate_id, p_time_used)
    ON CONFLICT ("passedMotionId", "delegateId") DO UPDATE SET "timeUsed" = EXCLUDED."timeUsed";
END;
$$;


ALTER PROCEDURE public.sp_record_delegate_participation(IN p_passed_motion_id character varying, IN p_delegate_id character varying, IN p_time_used integer) OWNER TO postgres;

--
-- Name: sp_register_delegate_attendance(character varying, integer, public."State"); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sp_register_delegate_attendance(IN p_delegate_id character varying, IN p_session_id integer, IN p_state public."State")
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO "Asistencia" ("delegateId", "sessionId", state)
    VALUES (p_delegate_id, p_session_id, p_state)
    ON CONFLICT ("delegateId", "sessionId") DO UPDATE SET state = EXCLUDED.state;
END;
$$;


ALTER PROCEDURE public.sp_register_delegate_attendance(IN p_delegate_id character varying, IN p_session_id integer, IN p_state public."State") OWNER TO postgres;

--
-- Name: sp_update_session_status(integer, public."SessionStatus"); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sp_update_session_status(IN p_session_id integer, IN p_new_status public."SessionStatus")
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE "Session"
    SET status = p_new_status
    WHERE id = p_session_id;
END;
$$;


ALTER PROCEDURE public.sp_update_session_status(IN p_session_id integer, IN p_new_status public."SessionStatus") OWNER TO postgres;

--
-- Name: total_time_used_in_motion(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.total_time_used_in_motion(p_motion_id text) RETURNS text
    LANGUAGE sql
    AS $$
  SELECT
    CONCAT(
      FLOOR(COALESCE(SUM("timeUsed"), 0) / 60),
      ' minutes ',
      COALESCE(SUM("timeUsed"), 0) % 60,
      ' seconds'
    )
  FROM "PassedMotionDelegate"
  WHERE "passedMotionId" = p_motion_id;
$$;


ALTER FUNCTION public.total_time_used_in_motion(p_motion_id text) OWNER TO postgres;

--
-- Name: update_motion_in_favor_votes_on_delegate_participation(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_motion_in_favor_votes_on_delegate_participation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.timeUsed > 0 THEN
        UPDATE "Motion"
        SET "inFavorVotes" = "inFavorVotes" + 1
        WHERE id = (SELECT "motionId" FROM "PassedMotion" WHERE id = NEW.passedMotionId);
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_motion_in_favor_votes_on_delegate_participation() OWNER TO postgres;

--
-- Name: update_passed_motion_status_on_delegate_update(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_passed_motion_status_on_delegate_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    all_delegates_have_spoken BOOLEAN;
BEGIN
    SELECT TRUE INTO all_delegates_have_spoken
    FROM "PassedMotion" pm
    JOIN "PassedMotionDelegate" pmd ON pm.id = pmd."passedMotionId"
    WHERE pm.id = NEW.passedMotionId
    GROUP BY pm.id
    HAVING SUM(CASE WHEN pmd."timeUsed" > 0 THEN 1 ELSE 0 END) = COUNT(*);

    IF all_delegates_have_spoken THEN
        UPDATE "PassedMotion" SET status = 'FINISHED' WHERE id = NEW.passedMotionId;
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_passed_motion_status_on_delegate_update() OWNER TO postgres;

--
-- Name: update_session_status_on_end_time_update(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_session_status_on_end_time_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW."endTime" IS NOT NULL AND OLD."endTime" IS NULL THEN
        UPDATE "Session" SET status = 'FINISHED' WHERE id = NEW.id;
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_session_status_on_end_time_update() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Asistencia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Asistencia" (
    id integer NOT NULL,
    "delegateId" text NOT NULL,
    "sessionId" integer NOT NULL,
    state public."State" NOT NULL
);


ALTER TABLE public."Asistencia" OWNER TO postgres;

--
-- Name: Asistencia_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Asistencia_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Asistencia_id_seq" OWNER TO postgres;

--
-- Name: Asistencia_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Asistencia_id_seq" OWNED BY public."Asistencia".id;


--
-- Name: Chair; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Chair" (
    id text NOT NULL,
    name text NOT NULL,
    "clerkId" text,
    email text,
    role public."Role" NOT NULL,
    "committeeId" integer NOT NULL
);


ALTER TABLE public."Chair" OWNER TO postgres;

--
-- Name: Committee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Committee" (
    id integer NOT NULL,
    name text NOT NULL,
    topic text NOT NULL,
    level public."Level" NOT NULL
);


ALTER TABLE public."Committee" OWNER TO postgres;

--
-- Name: Committee_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Committee_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Committee_id_seq" OWNER TO postgres;

--
-- Name: Committee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Committee_id_seq" OWNED BY public."Committee".id;


--
-- Name: Country; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Country" (
    id integer NOT NULL,
    name text NOT NULL,
    emoji text
);


ALTER TABLE public."Country" OWNER TO postgres;

--
-- Name: Country_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Country_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Country_id_seq" OWNER TO postgres;

--
-- Name: Country_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Country_id_seq" OWNED BY public."Country".id;


--
-- Name: Delegate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Delegate" (
    id text NOT NULL,
    name text NOT NULL,
    "countryId" integer NOT NULL,
    "committeeId" integer NOT NULL
);


ALTER TABLE public."Delegate" OWNER TO postgres;

--
-- Name: Motion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Motion" (
    id text NOT NULL,
    type public."MotionType" NOT NULL,
    topic text,
    "totalTime" integer NOT NULL,
    "timePerDelegate" integer,
    "maxDelegates" integer,
    "proposedBy" text NOT NULL,
    "committeeId" integer NOT NULL,
    "sessionId" integer NOT NULL,
    "inFavorVotes" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Motion" OWNER TO postgres;

--
-- Name: PassedMotion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PassedMotion" (
    id text NOT NULL,
    "motionId" text NOT NULL,
    "startTime" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    status public."MotionStatus" DEFAULT 'ONGOING'::public."MotionStatus" NOT NULL
);


ALTER TABLE public."PassedMotion" OWNER TO postgres;

--
-- Name: PassedMotionDelegate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PassedMotionDelegate" (
    id text NOT NULL,
    "passedMotionId" text NOT NULL,
    "delegateId" text NOT NULL,
    "speakingOrder" integer,
    "timeUsed" integer DEFAULT 0 NOT NULL,
    notes text
);


ALTER TABLE public."PassedMotionDelegate" OWNER TO postgres;

--
-- Name: Session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Session" (
    id integer NOT NULL,
    date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "startTime" timestamp(3) without time zone NOT NULL,
    "endTime" timestamp(3) without time zone,
    status public."SessionStatus" DEFAULT 'ONGOING'::public."SessionStatus" NOT NULL
);


ALTER TABLE public."Session" OWNER TO postgres;

--
-- Name: Session_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Session_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Session_id_seq" OWNER TO postgres;

--
-- Name: Session_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Session_id_seq" OWNED BY public."Session".id;


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: Asistencia id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Asistencia" ALTER COLUMN id SET DEFAULT nextval('public."Asistencia_id_seq"'::regclass);


--
-- Name: Committee id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Committee" ALTER COLUMN id SET DEFAULT nextval('public."Committee_id_seq"'::regclass);


--
-- Name: Country id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Country" ALTER COLUMN id SET DEFAULT nextval('public."Country_id_seq"'::regclass);


--
-- Name: Session id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Session" ALTER COLUMN id SET DEFAULT nextval('public."Session_id_seq"'::regclass);


--
-- Data for Name: Asistencia; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Asistencia" (id, "delegateId", "sessionId", state) FROM stdin;
\.
COPY public."Asistencia" (id, "delegateId", "sessionId", state) FROM '$$PATH$$/4554.dat';

--
-- Data for Name: Chair; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Chair" (id, name, "clerkId", email, role, "committeeId") FROM stdin;
\.
COPY public."Chair" (id, name, "clerkId", email, role, "committeeId") FROM '$$PATH$$/4545.dat';

--
-- Data for Name: Committee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Committee" (id, name, topic, level) FROM stdin;
\.
COPY public."Committee" (id, name, topic, level) FROM '$$PATH$$/4547.dat';

--
-- Data for Name: Country; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Country" (id, name, emoji) FROM stdin;
\.
COPY public."Country" (id, name, emoji) FROM '$$PATH$$/4552.dat';

--
-- Data for Name: Delegate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Delegate" (id, name, "countryId", "committeeId") FROM stdin;
\.
COPY public."Delegate" (id, name, "countryId", "committeeId") FROM '$$PATH$$/4550.dat';

--
-- Data for Name: Motion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Motion" (id, type, topic, "totalTime", "timePerDelegate", "maxDelegates", "proposedBy", "committeeId", "sessionId", "inFavorVotes", "createdAt") FROM stdin;
\.
COPY public."Motion" (id, type, topic, "totalTime", "timePerDelegate", "maxDelegates", "proposedBy", "committeeId", "sessionId", "inFavorVotes", "createdAt") FROM '$$PATH$$/4555.dat';

--
-- Data for Name: PassedMotion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PassedMotion" (id, "motionId", "startTime", status) FROM stdin;
\.
COPY public."PassedMotion" (id, "motionId", "startTime", status) FROM '$$PATH$$/4556.dat';

--
-- Data for Name: PassedMotionDelegate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PassedMotionDelegate" (id, "passedMotionId", "delegateId", "speakingOrder", "timeUsed", notes) FROM stdin;
\.
COPY public."PassedMotionDelegate" (id, "passedMotionId", "delegateId", "speakingOrder", "timeUsed", notes) FROM '$$PATH$$/4557.dat';

--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Session" (id, date, "startTime", "endTime", status) FROM stdin;
\.
COPY public."Session" (id, date, "startTime", "endTime", status) FROM '$$PATH$$/4549.dat';

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
\.
COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM '$$PATH$$/4544.dat';

--
-- Name: Asistencia_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Asistencia_id_seq"', 990, true);


--
-- Name: Committee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Committee_id_seq"', 24, true);


--
-- Name: Country_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Country_id_seq"', 298, true);


--
-- Name: Session_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Session_id_seq"', 9, true);


--
-- Name: Asistencia Asistencia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Asistencia"
    ADD CONSTRAINT "Asistencia_pkey" PRIMARY KEY (id);


--
-- Name: Chair Chair_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Chair"
    ADD CONSTRAINT "Chair_pkey" PRIMARY KEY (id);


--
-- Name: Committee Committee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Committee"
    ADD CONSTRAINT "Committee_pkey" PRIMARY KEY (id);


--
-- Name: Country Country_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Country"
    ADD CONSTRAINT "Country_pkey" PRIMARY KEY (id);


--
-- Name: Delegate Delegate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Delegate"
    ADD CONSTRAINT "Delegate_pkey" PRIMARY KEY (id);


--
-- Name: Motion Motion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Motion"
    ADD CONSTRAINT "Motion_pkey" PRIMARY KEY (id);


--
-- Name: PassedMotionDelegate PassedMotionDelegate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PassedMotionDelegate"
    ADD CONSTRAINT "PassedMotionDelegate_pkey" PRIMARY KEY (id);


--
-- Name: PassedMotion PassedMotion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PassedMotion"
    ADD CONSTRAINT "PassedMotion_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Asistencia_delegateId_sessionId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Asistencia_delegateId_sessionId_key" ON public."Asistencia" USING btree ("delegateId", "sessionId");


--
-- Name: Chair_clerkId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Chair_clerkId_key" ON public."Chair" USING btree ("clerkId");


--
-- Name: Chair_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Chair_email_key" ON public."Chair" USING btree (email);


--
-- Name: Committee_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Committee_name_key" ON public."Committee" USING btree (name);


--
-- Name: PassedMotionDelegate_passedMotionId_delegateId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "PassedMotionDelegate_passedMotionId_delegateId_key" ON public."PassedMotionDelegate" USING btree ("passedMotionId", "delegateId");


--
-- Name: PassedMotion_motionId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "PassedMotion_motionId_key" ON public."PassedMotion" USING btree ("motionId");


--
-- Name: Asistencia prevent_delegate_participation_in_overlapping_sessions_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER prevent_delegate_participation_in_overlapping_sessions_trigger BEFORE INSERT ON public."Asistencia" FOR EACH ROW EXECUTE FUNCTION public.prevent_delegate_participation_in_overlapping_sessions();


--
-- Name: Session set_default_start_time_for_session_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_default_start_time_for_session_trigger BEFORE INSERT ON public."Session" FOR EACH ROW EXECUTE FUNCTION public.set_default_start_time_for_session();


--
-- Name: PassedMotionDelegate update_motion_in_favor_votes_on_delegate_participation_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_motion_in_favor_votes_on_delegate_participation_trigger AFTER UPDATE OF "timeUsed" ON public."PassedMotionDelegate" FOR EACH ROW EXECUTE FUNCTION public.update_motion_in_favor_votes_on_delegate_participation();


--
-- Name: PassedMotionDelegate update_passed_motion_status_on_delegate_update_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_passed_motion_status_on_delegate_update_trigger AFTER UPDATE OF "timeUsed" ON public."PassedMotionDelegate" FOR EACH ROW EXECUTE FUNCTION public.update_passed_motion_status_on_delegate_update();


--
-- Name: Session update_session_status_on_end_time_update_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_session_status_on_end_time_update_trigger AFTER UPDATE OF "endTime" ON public."Session" FOR EACH ROW EXECUTE FUNCTION public.update_session_status_on_end_time_update();


--
-- Name: Asistencia Asistencia_delegateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Asistencia"
    ADD CONSTRAINT "Asistencia_delegateId_fkey" FOREIGN KEY ("delegateId") REFERENCES public."Delegate"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Asistencia Asistencia_sessionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Asistencia"
    ADD CONSTRAINT "Asistencia_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES public."Session"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Chair Chair_committeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Chair"
    ADD CONSTRAINT "Chair_committeeId_fkey" FOREIGN KEY ("committeeId") REFERENCES public."Committee"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Delegate Delegate_committeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Delegate"
    ADD CONSTRAINT "Delegate_committeeId_fkey" FOREIGN KEY ("committeeId") REFERENCES public."Committee"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Delegate Delegate_countryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Delegate"
    ADD CONSTRAINT "Delegate_countryId_fkey" FOREIGN KEY ("countryId") REFERENCES public."Country"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Motion Motion_committeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Motion"
    ADD CONSTRAINT "Motion_committeeId_fkey" FOREIGN KEY ("committeeId") REFERENCES public."Committee"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Motion Motion_proposedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Motion"
    ADD CONSTRAINT "Motion_proposedBy_fkey" FOREIGN KEY ("proposedBy") REFERENCES public."Delegate"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Motion Motion_sessionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Motion"
    ADD CONSTRAINT "Motion_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES public."Session"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PassedMotionDelegate PassedMotionDelegate_delegateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PassedMotionDelegate"
    ADD CONSTRAINT "PassedMotionDelegate_delegateId_fkey" FOREIGN KEY ("delegateId") REFERENCES public."Delegate"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PassedMotionDelegate PassedMotionDelegate_passedMotionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PassedMotionDelegate"
    ADD CONSTRAINT "PassedMotionDelegate_passedMotionId_fkey" FOREIGN KEY ("passedMotionId") REFERENCES public."PassedMotion"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PassedMotion PassedMotion_motionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PassedMotion"
    ADD CONSTRAINT "PassedMotion_motionId_fkey" FOREIGN KEY ("motionId") REFERENCES public."Motion"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DATABASE armun; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON DATABASE armun TO armun_app;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO armun_app;


--
-- Name: TABLE "Asistencia"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."Asistencia" TO armun_app;


--
-- Name: SEQUENCE "Asistencia_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."Asistencia_id_seq" TO armun_app;


--
-- Name: TABLE "Chair"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."Chair" TO armun_app;


--
-- Name: TABLE "Committee"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."Committee" TO armun_app;


--
-- Name: SEQUENCE "Committee_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."Committee_id_seq" TO armun_app;


--
-- Name: TABLE "Country"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."Country" TO armun_app;


--
-- Name: SEQUENCE "Country_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."Country_id_seq" TO armun_app;


--
-- Name: TABLE "Delegate"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."Delegate" TO armun_app;


--
-- Name: TABLE "Motion"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."Motion" TO armun_app;


--
-- Name: TABLE "PassedMotion"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."PassedMotion" TO armun_app;


--
-- Name: TABLE "PassedMotionDelegate"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."PassedMotionDelegate" TO armun_app;


--
-- Name: TABLE "Session"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."Session" TO armun_app;


--
-- Name: SEQUENCE "Session_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public."Session_id_seq" TO armun_app;


--
-- Name: TABLE _prisma_migrations; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public._prisma_migrations TO armun_app;


--
-- PostgreSQL database dump complete
--

